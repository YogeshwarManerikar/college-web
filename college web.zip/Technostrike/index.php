<!DOCTYPE html>
<html>
<head>
	
	<title>College Website</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/dycalendar.min.css">
	  <link  href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>

<nav link="white">
	<p class="logo" id="logo_ink"></p>
	<ul> 
		
		
		<li class="bracket"><a href="#" >Faculty</a></li>
		<li class="bracket"><a href="forms/second.html" >Registrations</a></li>
		<li class="bracket"><a href="course/cources.html" >Course</a></li>
		<li class="bracket"><a href="#" >Contact Us</a></li>
		<li id="bracket"><a href="forms/Admision.html">Admision</a></li>
		<li class="bracket"><a href="forms/OnlineCourse.html" >Online Course</a></li>
	</ul>

</nav>

<div class="putcalender">
	<div id="calender" class="dycalendar-container skin-green shadow-default"></div>
		<div>
			<script src="js/dycalendar.min.js"></script>
			
			<script>
			dycalendar.draw({

				target: "#calender",
				type: "month",
				highlighttoday:true
			});




			
			</script>
		
		</div>
	</div>



<!---<div class="container">
   
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <!--<ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>-->

    <div id="myslider" class="carousel slide" data-ride="carousel">

    	<ol class="carousel-indicators">
    		
    		<li data-target="#myslider" data-slide-to="0" class="active"></li>
    		<li data-target="#myslider" data-slide-to="1" ></li>
    		<li data-target="#myslider" data-slide-to="2" ></li>
    		
 
 		</ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="image/IMG-20190105-WA0020.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="image/IMG-20190105-WA0019.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="image/helicopter-2966569_1920.jpg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="carousel-control left" href="#myslider" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class=" carousel-control right" href="#myslider" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>



<div>
	<div>
		<div class="Home" id="Home_link">
			About us 

			<br>
			<br>
			

			<p>College was established in 2011 by the GOVERNMENT  under the name of Government College.
The College is situated in North Goa on Mahatma Gandhi Marg (Ring Road) near Raja Garden, Goa and is accessible from all corners of Goa.
`With the help of its dynamic staff, the college strives for excellence in education, sports, and co-curricular wellbeing of its students which make our college popular among particular area.</p>

<p>Initially the college was started in a school building with negligible facilities but with the efforts of the Governing Bodies, faculty and administrative staff, the college becomes one of the best colleges of University of Goa. 
Our college today is looked upon by the academic community  as one of the most excellent institutions for its progressive outlook towards teaching, learning and co-curricular activities. We are committed to provide an enabling environment in which holistic growth of every student is possible.</p>
			<br><br>
			<marquee><h2><b>We deliver future</b></h2></marquee>
 			<br><br>
			<div class="link">
			<a href="student/student%20faculty.html"> <h3> Student Section </h3></a>
			
			<a href="Isa%20-II.ics"> <h3> ISA II </h3></a>
			
			<a href="student_inf.html"><h3>View student Entry</h3></a>
				
			<a href="events.ics"> <h3> Event </h3></a>


			</div>
		</div>
	</div>
</div>






<div>
	<div>
		<div>
			<div class="Results" id="Results_link">
				<strong>Results</strong>
				<br>
				<br>
				<h5>See the results of Bcom <a href=""><b>know more</b></a></h5>
				<h5>See the results of BCA <a href=""><b>know more</b></a></h5>
				<h5>See the results of BBA <a href=""><b>know more</b></a></h5>
				<h5>See the results of BA <a href=""><b>know more</b></a></h5>
				<h5>See the results of Bsc <a href=""><b>know more</b></a></h5>
			</div>
		</div>
	</div>
</div>


<div>
	<div>
		<div class="Events" id="Events_link">
			<strong>Events</strong>
			<br>
			<br>
			<h5> Events happened in Bcom <a href=""><b>know more</b></a></h5>
				<h5> Event happened in BCA <a href=""><b>know more</b></a></h5>
				<h5>Event happened in BBA <a href=""><b>know more</b></a></h5>
				<h5>Event happened in BA <a href=""><b>know more</b></a></h5>
				<h5>Event happened in Bsc <a href=""><b>know more</b></a></h5>
		</div>
	</div>
</div>


<div>
	<div>
		<div class="important" id="important_link">
			<strong> Important </strong>
			<h5>Crossword competition for BCA <a href=""><b>know more</b></a></h5>
			<h5>Communication skill workshop for Bcom <a href=""><b>know more</b></a></h5>
			<h5>Mutual funds workshop for Bcom <a href=""><b>know more</b></a></h5>
		</div>
	</div>
</div>


<div>
	<div>
		<div class="box" id="box_link">
			
		</div>
	</div>
</div>

<div>

	<div>
		<div class="innerbox" id="inner_link">
			Follow us on 

			<ul class="social">
				<a href="https://www.facebook.com"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
	            <a href="https://twitter.com"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
	            <a href="https://plus.google.com"><i id="social-gp" class="fa fa-google-plus-square fa-3x social"></i></a>
	            <a href="mailto:shibinshajimac294@gmail.com"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
			</ul>
			
			<ul>
			<img src="image/1.jpg" class="visitors" id="visitors_link">
			</ul>
			<ul class="maps" id="map_link">
			<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30767.95805943486!2d73.93344434571623!3d15.430834313782123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbfbbcef9e074b7%3A0xbc7b9eec8c9a9dd8!2sM+I+B+K+High+School!5e0!3m2!1sen!2sin!4v1546772838780" width="400" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></center>
			</ul>

			<ul class="Address" id="Address_link">
				
			</ul>

		</div>
	</div>
</div>


<div>
	<div>
		<div class="visitors" id="visitors_link">
			 
		</div>
	</div>
</div>



</body>
</html>